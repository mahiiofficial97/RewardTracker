package com.rewardtracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RewardTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
