package com.rewardtracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RewardTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RewardTrackerApplication.class, args);
	}

}
